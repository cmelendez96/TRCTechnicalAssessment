/*For Sample Run */

SELECT * FROM Prob2.Employees
	WHERE ManagerID = 2

/*We want to get the employees whose ManagerID = selected employees ID + 1.
If an employee whose ManagerId = x;
We want to check the ManagerID's which are x+1
Go through the column of manager ID and select values which = X+2 */


