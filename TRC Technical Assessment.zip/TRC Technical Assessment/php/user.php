<?php

class user{
  protected $id;
  protected $firstname;
  protected $lastname;
  protected $email;
  protected $favoritecolor;
  protected $birthdate;
  protected $hobbies;
  private $password;

  function calculate_age(){
    $today = strtotime(date('Y')); //Getting todays year only
    $birthday = strtotime(date('Y'),strtotime($row['birthdate'])));
    $ageyear = $today - $birthday; //Difference
    return $ageyear;
  }

  function get_hobbies() {
    return $this->hobbies;
  }

  //Useful methods
  //Display variables id, firstname, email etc. we just change var.
  function displayVariable(){
    echo $this->var;
  }
}
?>
