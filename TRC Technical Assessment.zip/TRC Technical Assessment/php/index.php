<?php

$user = new user($SESSION->userid); // Assume $SESSION gets you all you need.
echo('<h1>My profile</h1>');

echo 'Hi, my name is $user->firstname $user->lastnamename.'
 echo 'I am $user->calculate_age() years old'

 if ($user->calculate_age() > 35) {
  echo 'I'm old enough to run for President of the United States if I really wanted to! That's pretty cool if you
  ask me.'}

  if ($user->hobbies)
    foreach($user->hobbies as $foo) {
      echo '<li>$foo</li>
    }

  echo 'And that about sums up my profile. Thanks for reading until the very end!';
  echo '<div style='display:none;'>$user->password</div>';

?>
