/*SELECT * FROM Testing.Schedule;

/*SELECT Station from Schedule
	where Station = "Sacramento";*/

/*SELECT Time from Schedule
	Where Station = "Sacramento" OR
    Station = "Stockton";*/
    
/*CREATE TABLE fakeTable AS
SELECT BusNumber, Station, Time
FROM Schedule
WHERE Station = "Sacramento";*/
/*CREATE TABLE fakeTable2 AS
SELECT * FROM Schedule
WHERE Station = "Sacramento" OR
Station = "Elk Grove" OR
Station = "Lodi" OR
Station = "Stockton" OR
Station = "Manteca";

/*SELECT * FROM fakeTable2;
ALTER TABLE fakeTable2
ADD Total_Travel_Time time;
SELECT * FROM fakeTable2;*/

SELECT *
	,Time - LAG(Time, 1) OVER (ORDER BY Time)
FROM Schedule;
/*I am able to get the difference between a rows time and its following row*/







